A Pen created at CodePen.io. You can find this one at https://codepen.io/afranks5/pen/xaXpYe.

 this is the starter file to my web development portfolio
Author: Alex Franks
Date Created: 9/6/2018
Github: afranks5
